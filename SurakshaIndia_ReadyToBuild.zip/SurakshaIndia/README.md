# Suraksha India — Android project

This ZIP contains the Android source project, not a prebuilt APK.

## Build the APK with GitHub Actions
1. Upload the **contents** of this folder to the root of your GitHub repository (replace the old files).
2. Open the repository's **Actions** tab.
3. Select **Build Suraksha India APK** and choose **Run workflow**.
4. When the run completes successfully, open it and download the artifact named **Suraksha-India-Release-APK**.
5. The APK is inside the downloaded artifact ZIP.

The workflow installs JDK 17, Gradle 8.4, Android SDK platform 34 and build-tools 34.0.0.

## Included features in the source
- Offline safety guides
- Locally stored trusted contacts
- SOS flow that prepares an SMS with optional location coordinates
- Indian emergency helpline screen
- Flashlight utility where supported
- Simulated incoming-call screen (not a real emergency/police call)

## Important
- An APK has **not** been compiled or tested in this environment. Do not distribute or rely on this app until the build succeeds and you test it on your phone.
- Test SOS using your own test number and consenting contacts, not emergency services.
- SMS delivery is not guaranteed. GPS may be unavailable indoors or when permissions/location are off.
- Verify emergency numbers and safety content against official sources before public distribution.
- This is not an official government app. Prepare a privacy policy before public distribution.
- Release output currently uses the Android debug signing configuration for testing; it is not a Play Store-ready production signing setup.

Application ID: `com.suraksha.india`
